package controle;

import java.util.ArrayList;
import model.Produto;

public class ProdutoControle {

    public static ArrayList<Produto> listaProdutos = new ArrayList<>();

    public void cadastrarProduto(Produto produto) {
        listaProdutos.add(produto);
        System.out.println("Produto cadastrado com sucesso!");
    }

    public void listarProdutos() {
        if (listaProdutos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
            return;
        }
        for (Produto p : listaProdutos) {
            System.out.println(p);
        }
    }

    public Produto buscarProduto(int id) {
        for (Produto p : listaProdutos) {
            if (p.getId() == id) {
                return p;
            }
        }
        System.out.println("Produto nao encontrado!");
        return null;
    }

    public void atualizarProduto(int id, String novoNome, double novoPreco) {
        Produto p = buscarProduto(id);
        if (p != null) {
            p.setNome(novoNome);
            p.setPreco(novoPreco);
            System.out.println("Produto atualizado com sucesso!");
        }
    }

    public void removerProduto(int id) {
        Produto remover = buscarProduto(id);
        if (remover != null) {
            listaProdutos.remove(remover);
            System.out.println("Produto removido com sucesso!");
        }
    }
}
