package com.ucb.poo.sorveteria;

import controle.ProdutoControle;
import model.Milkshake;
import model.Sorvete;
import model.Acai;
import model.Picole;

import java.util.Scanner;

public class Produtos {

    static Scanner sc = new Scanner(System.in);
    static ProdutoControle controle = new ProdutoControle();

    public static void menuProdutos() {

        int opcao;

        do {
            System.out.println("\n===== PRODUTOS =====");
            System.out.println("1 - Cadastrar produto");
            System.out.println("2 - Listar produtos");
            System.out.println("3 - Buscar produto");
            System.out.println("4 - Atualizar produto");
            System.out.println("5 - Remover produto");
            System.out.println("0 - Voltar");
            System.out.print("Opcao: ");

            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {

                case 1:
                    System.out.println("Tipo: 1-Sorvete  2-Milkshake  3-Acai  4-Picole");
                    int tipo = sc.nextInt(); sc.nextLine();

                    System.out.print("ID: ");
                    int id = sc.nextInt(); sc.nextLine();

                    System.out.print("Nome: ");
                    String nome = sc.nextLine();

                    System.out.print("Preco: ");
                    double preco = sc.nextDouble(); sc.nextLine();

                    System.out.print("Estoque inicial: ");
                    int estoque = sc.nextInt(); sc.nextLine();

                    if (tipo == 1) {
                        System.out.print("Sabor: ");
                        String sabor = sc.nextLine();
                        controle.cadastrarProduto(new Sorvete(id, nome, preco, estoque, sabor));
                    } else if (tipo == 2) {
                        System.out.print("Volume (ml): ");
                        int ml = sc.nextInt(); sc.nextLine();
                        controle.cadastrarProduto(new Milkshake(id, nome, preco, estoque, ml));
                    } else if (tipo == 3) {
                        System.out.print("Tamanho (P/M/G): ");
                        String tamanho = sc.nextLine();
                        controle.cadastrarProduto(new Acai(id, nome, preco, estoque, tamanho));
                    } else if (tipo == 4) {
                        System.out.print("Sabor: ");
                        String sabor = sc.nextLine();
                        controle.cadastrarProduto(new Picole(id, nome, preco, estoque, sabor));
                    } else {
                        System.out.println("Tipo invalido!");
                    }
                    break;

                case 2:
                    controle.listarProdutos();
                    break;

                case 3:
                    System.out.print("ID do produto: ");
                    int idBusca = sc.nextInt(); sc.nextLine();
                    var p = controle.buscarProduto(idBusca);
                    if (p != null) System.out.println(p);
                    break;

                case 4:
                    System.out.print("ID do produto a atualizar: ");
                    int idAtualizar = sc.nextInt(); sc.nextLine();
                    System.out.print("Novo nome: ");
                    String novoNome = sc.nextLine();
                    System.out.print("Novo preco: ");
                    double novoPreco = sc.nextDouble(); sc.nextLine();
                    controle.atualizarProduto(idAtualizar, novoNome, novoPreco);
                    break;

                case 5:
                    System.out.print("ID do produto a remover: ");
                    int idRemover = sc.nextInt(); sc.nextLine();
                    controle.removerProduto(idRemover);
                    break;

                case 0:
                    System.out.println("Voltando...");
                    break;

                default:
                    System.out.println("Opcao invalida!");
            }

        } while (opcao != 0);
    }
}
